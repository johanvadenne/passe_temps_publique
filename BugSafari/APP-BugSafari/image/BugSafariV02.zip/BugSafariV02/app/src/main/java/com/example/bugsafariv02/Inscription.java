package com.example.bugsafariv02;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import java.util.HashMap;
import java.util.Map;

public class Inscription extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.inscription);

        Button BtnInscription = findViewById(R.id.BtnInscription);

        TextView ChampUtilisateur = findViewById(R.id.champUtilisateur);
        TextView ChampNom = findViewById(R.id.champNom);
        TextView ChampPrenom = findViewById(R.id.champPrenom);
        TextView ChampMail = findViewById(R.id.champMail);
        TextView ChampMDP = findViewById(R.id.champMDP);

        BtnInscription.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String utilisateur = ChampUtilisateur.getText().toString();
                String nom = ChampNom.getText().toString();
                String prenom = ChampPrenom.getText().toString();
                String mail = ChampMail.getText().toString();
                String mdp = ChampMDP.getText().toString();
                mdp = sha1.encryptThisString(mdp);


                String jsonColonne =
                        "{\"AddresseMail\": \"STR\"," +
                                "\"Nom\": \"STR\"," +
                                "\"Prenom\": \"STR\"," +
                                "\"NomUtilisateur\": \"STR\"," +
                                "\"Mdp\": \"STR\"}";
                String jsonValeur =
                        "[{\"AddresseMail\": \""+mail+"\"," +
                                "\"Nom\": \""+nom+"\"," +
                                "\"Prenom\": \""+prenom+"\"," +
                                "\"NomUtilisateur\": \""+utilisateur+"\"," +
                                "\"Mdp\": \""+mdp+"\"}]";

                String url = "http://172.16.197.253:8080/api/CompteUtilisateur";

                Map<String, String> parametres = new HashMap<>();
                parametres.put("colonnes", jsonColonne);
                parametres.put("valeurs", jsonValeur);
                // Appeler cette ligne dans votre gestionnaire de clics ou tout autre endroit approprié
                new Post(url, parametres).execute();

            }



        });
    }
}
