package com.example.bugsafariv02;

import android.os.AsyncTask;
import android.util.Log;

import java.io.BufferedWriter;
import java.io.IOException;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.util.Map;

public class Post extends AsyncTask<Void, Void, Void> {

    private String url;
    private Map<String, String> parametres;

    public Post(String url, Map<String, String> parametres) {
        this.url = url;
        this.parametres = parametres;
    }

    @Override
    protected Void doInBackground(Void... voids) {
        try {
            URL urlObjet = new URL(url);
            HttpURLConnection connection = (HttpURLConnection) urlObjet.openConnection();

            // Configuration de la requête
            connection.setRequestMethod("POST");
            connection.setDoOutput(true); // Indique que nous allons envoyer des données

            // Construction des paramètres de la requête
            StringBuilder parametresRequete = new StringBuilder();
            for (Map.Entry<String, String> entry : parametres.entrySet()) {
                if (parametresRequete.length() != 0) {
                    parametresRequete.append('&');
                }
                parametresRequete.append(URLEncoder.encode(entry.getKey(), "UTF-8"));
                parametresRequete.append('=');
                parametresRequete.append(URLEncoder.encode(entry.getValue(), "UTF-8"));
                // exemple de JSON: colonnes:{"Nom":"STR","Age":"INT"}&valeurs:[{"Nom":"Johan","Age":"19"}]
            }

            // Envoi des données
            try (OutputStream outputStream = connection.getOutputStream(); // permet d'écrire des données dans cette connexion HTTP
                 BufferedWriter writer = new BufferedWriter(new OutputStreamWriter(outputStream, "UTF-8")) // permet d'écrire des caractères dans un flux de sortie
            ) {
                writer.write(parametresRequete.toString());
            }

            // Lecture de la réponse
            int reponseCode = connection.getResponseCode();
            String reponseRetour = connection.getResponseMessage();
            Log.d("RequeteHttpPost", String.valueOf(reponseCode));
            Log.d("RequeteHttpPost", reponseRetour);

            connection.disconnect();
        } catch (IOException e) {
            Log.e("RequeteHttpPost", "Erreur lors de la requête HTTP", e);
        }
        return null;
    }
}
